using Azure.Data.Tables;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.WindowsAzure.Storage.Table;
using OfficeOpenXml;
using ReporteriaWS.Services;
using System.Globalization;

// Obtener la configuraci�n
var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .Build();

// Crear un cliente HTTP con el tiempo de espera configurado
var httpClient = new HttpClient();
httpClient.Timeout = TimeSpan.FromMinutes(60);

var builder = WebApplication.CreateBuilder(args);

var cultureInfo = new CultureInfo("es-AR");

builder.Services.AddControllersWithViews();

builder.Services.AddHttpClient<Auth0Service>();

builder.Services.AddTransient<IAuth0Service, Auth0Service>();

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });
builder.Services.AddControllers();

 
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAllOrigins", builder =>
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader());
});
var app = builder.Build();
app.UseCors("AllowAllOrigins");
app.UseCors(policy => policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
//app.MapControllers();

app.Run();
 