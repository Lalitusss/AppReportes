﻿var config = {
    "R_startDate": {
        "type": "datetime",
        "nombre": "Fecha Desde"
    },
    "R_endDate": {
        "type": "datetime",
        "nombre": "Fecha Hasta"
    },
    "DateList": {
        "type": "array",
        "values": ["FechaDeTransferencia", "CreatedDate", "CreatedOnDataBase", "FechaDeCobro", "FechaCreacion"],
        "nombre": "Fecha"
    }
};

// Botón que muestra las respuestas
$('#log-button').on('click', function () {
    const respuestas = JSON.parse(localStorage.getItem('respuestas'));
    if (respuestas !== null && respuestas.length > 0) {
        const html = respuestas.map((respuesta, index) => {
            return `
                <tr>
                    <td>${index + 1}</td>
                    <td>${respuesta.reporte}</td>
                    <td>${respuesta.respuesta}</td>
                    <td>${respuesta.estado}</td>
                    <td>${respuesta.horaInicio}</td>
                    <td>${respuesta.horaFin}</td>
                    <td>
                      <a ${respuesta.archivo ? 'href="' + respuesta.archivo + '" target="_blank"' : ''}>
                        ${respuesta.archivo ? respuesta.archivoTexto : 'No hay archivo'}
                      </a>
                    </td>
                    <td style="display: none;">${respuesta.guidFromFE}</td>
                </tr>
            `;
        }).join('');
        Swal.fire({
            title: 'Respuestas',
            html: `
                    <div style="max-height: 275px; overflow-y: auto;">
                        <table>
                            <tr>
                                <th>#</th>
                                <th>Reporte</th>
                                <th>Respuesta</th>
                                <th>Estado</th>
                                <th>Hora Inicio</th>
                                <th>Hora Fin</th>
                                <th>Archivo</th>
                                <th style="display: none;">Guid</th>
                            </tr>
                            ${html}
                        </table>
                    </div>
                `,
            width: 'auto',
            customClass: {
                popup: 'small-font',
                title: 'titulo-popup'
            },
            confirmButtonColor: '#087868'
        });
    } else {
        Swal.fire({
            title: 'No hay respuestas',
            text: 'No se han enviado solicitudes aún.',
            icon: 'info',
            width: '20%',
            customClass: {
                popup: 'small-font'
            },
            confirmButtonColor: '#087868'
        });
    }
});

$('#dllEmpresa').on('change', function () {
    $('#inputs-container').html("");
    $("#verHistoricos").hide();
    var seleccionado = $(this).val();//Este seria el Id de Empresa
    if (seleccionado == 0) {
        $('#dllReporte').prop('disabled', true);
        $('#dllReporte').empty().append($('<option>').val('').text('Seleccione una opción'));
        return;
    }
    $.ajax({
        type: 'GET',
        url: '/Home/ObtenerOpciones',
        data: { empresa: $("#dllEmpresa option:selected").html() },
        dataType: 'json',
        success: function (data) {
            $('#dllReporte').prop('disabled', false);
            $('#dllReporte').empty().append(
                $('<option>').val('').text('Seleccione una opción')
            ).append($.map(data, function (value) {
                return $('<option>').val(value.id)
                    .text(value.texto)
                    .attr('queryParams', JSON.stringify(value.cantParam));
            }));
        }
    });
});

$('#dllReporte').on('change', function () {
    var htmlInputs = '';
    var seleccionado = $(this).find('option:selected');
    var queryParams = seleccionado.attr('queryParams');
    var params = JSON.parse(queryParams);
    var url = ValidarUrl($("#dllReporte option:selected").text().toUpperCase(), $("#dllEmpresa option:selected").html());
    if (url != "") {
        $("#verHistoricos").show();
        $("#descarga").attr("href", url);
    }
    else {
        $("#verHistoricos").hide();
    }
    $.each(params, function (index, param) {
        var nombre = config.DateList.values.includes(param) ? "Fecha Desde" : config[param].nombre;
        htmlInputs += '<div class="form-group mb-1">';
        var tipo = config.DateList.values.includes(param) ? config.DateList.type : config[param].type;
        switch (tipo) {
            case "datetime":
                htmlInputs += '<label for="' + param + '" class="small">' + nombre + '</label>';
                htmlInputs += '<input type="date" id="' + param + '" name="' + param + '" class="form-control border border-secondary rounded" required>';
                break;
            case "array":
                htmlInputs += '<div class="d-flex justify-content-start">';
                htmlInputs += '<div>';
                htmlInputs += '<label for="' + param + '" class="small">Fecha Desde</label>';
                htmlInputs += '<input type="date" id="' + param + '" name="' + param + '" class="form-control border border-secondary rounded fechaInicio" required>';
                htmlInputs += '</div>';
                htmlInputs += '<div style="margin-left: 10px;">';
                htmlInputs += '<label for="' + param + '" class="small">Fecha Hasta</label>';
                htmlInputs += '<input type="date" id="' + param + '" name="' + param + '" class="form-control border border-secondary rounded fechaFin" required>';
                htmlInputs += '</div>';
                htmlInputs += '</div>';
                break;
        }
        htmlInputs += '</div>';
    });

    $('#inputs-container').html(htmlInputs);
});

//Proceso de colas de solicitudes
let queue = [];
function sendRequest(data) {
    return new Promise((resolve, reject) => {
        $.ajax({
            type: 'POST',
            url: data.apiToConnect,
            contentType: 'application/json',
            data: JSON.stringify(data.params),
            dataType: 'json',
            success: (response) => {
                resolve(response);
            },
            error: (xhr, status, error) => {
                reject(xhr.responseText);
            }
        });
    });
}
function addRequestToQueue(data, horaInicio) {
    queue.push({ data, horaInicio });
    processQueue();
}
function processQueue() {
    if (queue.length > 0) {
        const { data, horaInicio } = queue.shift();
        const horaSolicitud = new Date().toLocaleTimeString();
        const guid = data.params.GuidFromFE;
        const cliente = data.params.Cliente;

        guardarRespuestaEnLocalStorage(data.reportToSend, '...', 'Solicitando', horaInicio, '...', '...', guid, cliente);

        sendRequest(data)
            .then((response) => {
                const horaFin = new Date().toLocaleTimeString();
                actualizarEstadoEnLocalStorage(data.reportToSend, response, 'Enviado', horaFin, cliente);
            })
            .catch((error) => {
                const horaFin = new Date().toLocaleTimeString();
                actualizarEstadoEnLocalStorage(data.reportToSend, error, 'No enviado', horaFin, cliente);
            });
    }
}
function actualizarEstadoEnLocalStorage(reportToSend, response, estado, horaFin, cliente) {
    const storedData = JSON.parse(localStorage.getItem('respuestas'));
    const index = storedData.findLastIndex((item) => item.reporte === reportToSend);

    if (index !== -1) {
        storedData[index].estado = estado;
        storedData[index].horaFin = horaFin;
        storedData[index].respuesta = response.mensaje == undefined ? response.replace(/<[^>]*>/g, '') : response.mensaje;
        storedData[index].archivo = response.fileUrl;
        storedData[index].archivoTexto = "Excel";
        /*        if (cliente === "1") {*/
        storedData[index].estado = "Solicitando";
        storedData[index].horaFin = "...";
        storedData[index].respuesta = "...";
        //}
        localStorage.setItem('respuestas', JSON.stringify(storedData));
    }
}
function guardarRespuestaEnLocalStorage(reportToSend, respuesta, estado, horaInicio, horaFin, archivo, guidFromFE, cliente) {
    const respuestas = JSON.parse(localStorage.getItem('respuestas')) || [];
    respuestas.push({
        reporte: reportToSend,
        respuesta: respuesta,
        estado: estado,
        horaInicio: horaInicio,
        horaFin: horaFin,
        archivoTexto: archivo,
        guidFromFE: guidFromFE,
        cliente: cliente
    });
    localStorage.setItem('respuestas', JSON.stringify(respuestas));
}
function mostrarMensajeSwal(titulo, texto, icono, textoButton, confirmButtonColor = '#087868', customClass = {}) {
    Swal.fire({
        title: titulo,
        text: texto,
        icon: icono,
        confirmButtonText: textoButton,
        confirmButtonColor: confirmButtonColor, // Añade el color del botón
        width: '25%',
        customClass: {
            confirmButton: customClass.confirmButton // Permite añadir clases CSS personalizadas
        }
    });
}

$('#reporte').on('click', function (event) {
    event.preventDefault();
    var empresaSeleccionada = $("#dllEmpresa").val();
    if (empresaSeleccionada === '0') {
        $("#verHistoricos").hide();
        mostrarMensajeSwal('Error', 'Empresa Inexistente.', 'error', 'Ok');
        return;
    };

    var reporteSeleccionado = $("#dllReporte").val();
    if (reporteSeleccionado === '') {
        $("#verHistoricos").hide();
        mostrarMensajeSwal('Error', 'Reporte Inexistente.', 'error', 'Ok');
        $("#verHistoricos").hide();
        return;
    };

    var apiToConnect = "/api/" + $("#dllEmpresa option:selected").html() + "?";
    var reportToSend = $("#dllReporte option:selected").html();
    var fechaInicio = '';
    var fechaFin = '';

    if (empresaSeleccionada === '1') {
        fechaInicio = $('.fechaInicio').val();
        fechaFin = $('.fechaFin').val();
    }
    else if (empresaSeleccionada === '2') {
        fechaInicio = $('#R_startDate').val();
        fechaFin = $('#R_endDate').val();
    }

    if (fechaInicio === '' || fechaFin === '') {
        mostrarMensajeSwal('Error', 'Por favor, complete las fechas antes de generar el reporte.', 'error', 'Ok');
        return false;
    }

    if (fechaInicio > fechaFin) {
        mostrarMensajeSwal('Error', 'La fecha inicial no puede ser mayor que la fecha final.', 'error', 'Ok');
        return false;
    }

    var guid = uuid.v4().replace('-', '').slice(0, 12);
    const data = {
        apiToConnect,
        params: {
            apiToConnect,
            report: reportToSend,
            queryParams: $("#dynamics").serialize(),
            GuidFromFE: guid,
            UserName: localStorage.getItem('User'),
            Cliente: empresaSeleccionada, // Aunque no se filtre, puedes incluir el valor si es necesario
        },
        reportToSend
    };
    const horaInicio = new Date().toLocaleTimeString();
    addRequestToQueue(data, horaInicio);

    mostrarMensajeSwal('Solicitud enviada', 'Su solicitud ha sido enviada correctamente.', 'success', 'Continuar');
});

function ValidarUrl(fileName, empresa) {
    var url = "";
    $.ajax({
        url: '/api/Action/GetSecureUrl', // URL del controlador
        type: 'GET', // Método de la solicitud
        data: { fileName: fileName, empresa: empresa }, // Datos a enviar
        success: function (response) {
            url = response.url;
        },
        error: function (xhr, status, error) {
            url = "";
        },
        async: false // Esto es importante para que el código se ejecute de manera síncrona
    });
    return url;
}

function obtenerReporteStatus() {
    let respuestas = localStorage.getItem('respuestas');
    let datos = [];
    if (respuestas) {
        respuestas = JSON.parse(respuestas);

        //let filtrados = respuestas.filter(item => item.cliente === "1" && item.estado === "Solicitando");
        let filtrados = respuestas.filter(item => item.estado === "Solicitando");

        datos = filtrados.map(({ reporte, respuesta, horaFin, archivoTexto, guidFromFE, cliente }) => ({
            reporte,
            respuesta,
            horaFin,
            archivoTexto,
            guidFromFE,
            cliente
        }));
    }

    if (datos.length === 0) {
        return;
    }

    $.ajax({
        type: "POST",
        url: "/api/Action/SetearLocalStorage",
        contentType: "application/json",
        data: JSON.stringify({ datos: datos }),
        success: function (data) {
            data.forEach(item => {
                if (item.estadoEnvio === 'Finalizado') {
                    var elementos = JSON.parse(localStorage.getItem('respuestas'));

                    var elementoEncontrado = elementos.find(function (elemento) {
                        return elemento.guidFromFE === item.rowKey;
                    });

                    if (elementoEncontrado) {
                        const horaFin = new Date().toLocaleTimeString();
                        elementoEncontrado.archivo = item.url;
                        elementoEncontrado.estado = "Enviado";
                        elementoEncontrado.guidFromFE = item.rowKey;
                        elementoEncontrado.horaFin = horaFin;
                        // elementoEncontrado.horaInicio = item.startDate;
                        elementoEncontrado.reporte = item.reportName;
                        elementoEncontrado.respuesta = "Operación exitosa";
                    }

                    localStorage.setItem('respuestas', JSON.stringify(elementos));
                } else if (item.estadoEnvio === 'Error') {
                    // Manejar el caso de error
                    console.error('Error en el proceso:', item);
                }
            });
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

// Ejecutar la función cada 5 segundos
setInterval(obtenerReporteStatus, 5000);
