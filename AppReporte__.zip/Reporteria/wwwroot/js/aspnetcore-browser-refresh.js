﻿(function () {
    var __browserRefresh = {
        init: function () {
            this.connect();
        },
        connect: function () {
            var ws = new WebSocket('ws://' + window.location.host + '/__browser-refresh');
            ws.onmessage = function (e) {
                if (e.data === 'reload') {
                    window.location.reload();
                }
            };
            ws.onerror = function () {
                console.log('Error de conexión con el servidor de actualización automática.');
            };
            ws.onclose = function () {
                console.log('Conexión con el servidor de actualización automática cerrada.');
                setTimeout(__browserRefresh.connect, 1000);
            };
        }
    };
    __browserRefresh.init();
})();