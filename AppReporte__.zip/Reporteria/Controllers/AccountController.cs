﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using ReporteriaWS.Models;
using System.Security.Claims;

public class AccountController : Controller
{
    private readonly IAuth0Service _auth0Service;

    public AccountController(IAuth0Service auth0Service)
    {
        _auth0Service = auth0Service;
    }

    [HttpGet]
    public IActionResult Login()
    {
        return View(new LoginViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            var token = await _auth0Service.AuthenticateAsync(model.Username!, model.Password!);
            var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, model.Username ?? string.Empty),
                    new Claim("AccessToken", token ?? string.Empty)
                };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal,
                new AuthenticationProperties
                {
                    IsPersistent = false
                });

            return RedirectToAction("Index", "Home");
        }
        catch (HttpRequestException ex)
        {
            // Capturamos el error específico de Auth0 (ej: "invalid_grant")
            ModelState.AddModelError(string.Empty, ex.Message);
        }
        catch (Exception)
        {
            ModelState.AddModelError(string.Empty, "Error interno. Intente nuevamente.");
        }
        return View(model);
    }

    [HttpGet]
    public async Task<IActionResult> Callback()
    {
        var authenticateResult = await HttpContext.AuthenticateAsync("Auth0");

        if (!authenticateResult.Succeeded)
        {
            return RedirectToAction("Login");
        }

        var claims = authenticateResult.Principal.Claims;

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        var principal = new ClaimsPrincipal(identity);

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "Home");
    }
}