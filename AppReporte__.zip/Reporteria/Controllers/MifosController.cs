﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ReporteriaWS.Services;
using static ReporteriaWS.Models.Connections;

namespace ReporteriaWS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MifosController : ControllerBase
    {
        private static readonly IConfiguration _configuration;
        private static readonly IExcelService _excelService;
        private static readonly ActionConn _mifos;

        static MifosController()
        {
            _configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            _mifos = new ActionConn
            {
                User = _configuration["Mifos:User"],
                Pass = _configuration["Mifos:Pass"],
                Url = _configuration["Mifos:Url"],
                UrlParams = _configuration["Mifos:UrlParams"]
            };

            _excelService = new ExcelService(new AzureBlobStorageService(_configuration));
        }
        [HttpPost]
        public async Task<IActionResult> CrearReporteMifos([FromBody] ReporteParam reporteParam)
        {
            try
            {
                var queueName = _configuration["AzureBlobStorage:QueueNameM"]!;
                var connectionString = _configuration["AzureBlobStorage:ABS"];

                var queueService = new QueueService(connectionString!, queueName);
                SetReporte(reporteParam);
                var res = await queueService.EnqueueMessageAsync(reporteParam);

                return Ok("Solicitando");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error al crear el reporte: {ex.Message}");
            }
        }
        public void SetReporte(ReporteParam reporteParam)
        {
            var rutaArchivo = Path.Combine(Directory.GetCurrentDirectory(), "Reportes", "Mifos.json");
            var json = System.IO.File.ReadAllText(rutaArchivo);
            var reportes = JsonConvert.DeserializeObject<List<Reporte>>(json);
            reporteParam.ReporteJson = reportes?.FirstOrDefault(r => r.Texto == reporteParam.Report);
        }
    }     
}