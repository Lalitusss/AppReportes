﻿using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ReporteriaWS.Services;
using static LocalStorage;

[ApiController]
[Route("api/[controller]")]
public class ActionController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly CloudTableClient _tableClient;

    public ActionController(IHttpClientFactory httpClientFactory, IConfiguration configuration)
    {
        _configuration = configuration;
        var connectionString = configuration["AzureBlobStorage:ABS"];
        var storageAccount = CloudStorageAccount.Parse(connectionString);
        _tableClient = storageAccount.CreateCloudTableClient();
    }

    [HttpPost]
    public async Task<IActionResult> CrearReporteAction([FromBody] ReporteParam reporteParam)
    {
        try
        {
            var queueName = _configuration["AzureBlobStorage:QueueNameA"]!;
            var connectionString = _configuration["AzureBlobStorage:ABS"];

            var queueService = new QueueService(connectionString!, queueName);
            SetReporte(reporteParam);

            // Preparar la condición WHERE
            var where = " WHERE 1=1 ";
            if (!string.IsNullOrEmpty(reporteParam.QueryParams))
            {
                var queryParams = reporteParam.QueryParams.Replace("=", "&").Replace("-", "");
                string[] partes = queryParams.Split('&');

                where = string.Format(" WHERE {0} BETWEEN '{1}' AND '{2}' ORDER BY {0} ",
                                      partes[0],
                                      partes[1].Insert(4, "-").Insert(7, "-"),
                                      partes[3].Insert(4, "-").Insert(7, "-"));                
                //where = string.Format(" WHERE CONVERT(DATE, {0}, 103) BETWEEN '{1}' AND '{2}' ORDER BY {0} ",
                //                      partes[0],
                //                      partes[1],
                //                      partes[3]);
            }

            reporteParam.QueryParams = where;

            var res = await queueService.EnqueueMessageAsync(reporteParam);

            return Ok("Solicitando");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error al crear el reporte: {ex.Message}");
        }
    }

    public void SetReporte(ReporteParam reporteParam)
    {
        var rutaArchivo = Path.Combine(Directory.GetCurrentDirectory(), "Reportes", "Action.json");
        var json = System.IO.File.ReadAllText(rutaArchivo);
        var reportes = JsonConvert.DeserializeObject<List<Reporte>>(json);
        reporteParam.ReporteJson = reportes?.FirstOrDefault(r => r.Texto == reporteParam.Report);
    }

    [HttpPost("SetearLocalStorage")]
    public async Task<IActionResult> SetearLocalStorageAsync([FromBody] DatosRequest request)
    {
        try
        {
            if (request == null || request.datos == null || !request.datos.Any())
            {
                return BadRequest("La solicitud no contiene datos válidos.");
            }
            var tabla = _tableClient.GetTableReference("ReporteStatus");
            var tareas = new List<Task<TableQuerySegment<ReporteStatusEntity>>>();

            foreach (var rowKey in request.datos)
            {
                var query = new TableQuery<ReporteStatusEntity>()
                    .Where(TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, rowKey.guidFromFE));

                tareas.Add(tabla.ExecuteQuerySegmentedAsync(query, null));
            }

            var resultados = await Task.WhenAll(tareas);

            var entidades = resultados.SelectMany(r => r.Results).ToList();

            return Ok(entidades);
        }
        catch (StorageException ex)
        {
            return StatusCode(500, "Error al acceder a los datos.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Error inesperado.");
        }
    }

    [HttpGet("GetSecureUrl")]
    public async Task<IActionResult> GetSecureUrlAsync(string fileName, string empresa)
    {
        try
        {
            var blobServiceClient = new BlobServiceClient(_configuration["AzureBlobStorage:ABS"]);
            var containerClient = blobServiceClient.GetBlobContainerClient(_configuration["AzureBlobStorage:ContainerName"]!);

            DateTime fecha = DateTime.Now;
            string fechaFormateada = fecha.ToString("yyyy_MM_dd");
            var fileNameCreated = "HISTORICO_" + fileName + "_" + fechaFormateada + ".xlsx";
            var blobClient = containerClient.GetBlobClient(empresa + @"/" + fileNameCreated);

            if (await blobClient.ExistsAsync())
            {
                return Ok(new { url = blobClient.Uri.ToString() });
            }
            else
            {
                return Ok(new { url = "" });
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error al generar la URL: {ex.Message}");
        }
    }

}

