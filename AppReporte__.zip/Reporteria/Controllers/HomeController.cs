﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ReporteriaWS.Controllers
{
    public class HomeController : Controller
    {
        [Authorize]
        public IActionResult Index()
        {
            if (!HttpContext.User.Identity?.IsAuthenticated ?? true)
            {
                return RedirectToAction("Login", "Account");
            }
            ViewBag.User = User.FindFirst(ClaimTypes.Name)?.Value;
            return View();
        }

        public IActionResult ObtenerOpciones(string empresa)
        {
            //Azure
            //var rutaArchivo = System.IO.File.ReadAllText(Path.Combine(Environment.GetEnvironmentVariable("HOME")!, "site", "wwwroot", "Reportes", empresa + ".json"));
            //Local
            var rutaArchivo = System.IO.File.ReadAllText("Reportes/" + empresa + ".json");
            return Ok(rutaArchivo);
        }
    }
}