﻿namespace ReporteriaWS.Models
{
    public class Connections
    {
        public class ActionConn
        {
            public string? User { get; set; }
            public string? Pass { get; set; }
            public string? Url { get; set; }
            public string? UrlParams { get; set; }
        }

        public class MifosConn
        {
            public string? Cobranzas { get; set; }
            public string? DatosPersonales { get; set; }
        }
    }
}