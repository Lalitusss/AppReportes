﻿namespace ReporteriaWS.Models
{
    public class Auth0TokenResponseModel
    {
        public string? access_token { get; set; }
        public string? id_token { get; set; }
    }
}