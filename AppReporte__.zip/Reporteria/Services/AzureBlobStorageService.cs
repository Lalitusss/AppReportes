﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace ReporteriaWS.Services
{
    public class AzureBlobStorageService
    {
        private readonly string? _conexionString;
        private readonly string? _nombreContenedor;

        public AzureBlobStorageService(IConfiguration configuration)
        {
            _conexionString = configuration["AzureBlobStorage:ABS"];
            _nombreContenedor = configuration["AzureBlobStorage:ContainerName"];
        }

        public async Task<string> SubirArchivo(Stream archivo, string nombreArchivo)
        {
            CloudStorageAccount cuenta = CloudStorageAccount.Parse(_conexionString);
            CloudBlobClient cliente = cuenta.CreateCloudBlobClient();
            CloudBlobContainer contenedor = cliente.GetContainerReference(_nombreContenedor);

            CloudBlockBlob blob = contenedor.GetBlockBlobReference(nombreArchivo);

            await blob.UploadFromStreamAsync(archivo);

            string url = blob.Uri.ToString();

            return url;
        }
    }
}