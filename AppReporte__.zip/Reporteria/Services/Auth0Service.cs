﻿using System.Text.Json;
using static Auth0Cast;

namespace ReporteriaWS.Services
{
    public class Auth0Service : IAuth0Service
    {
        private readonly HttpClient _httpClient;
        private readonly string _domain;
        private readonly string _clientId;
        private readonly string _clientSecret;
        private readonly string _audience;

        public Auth0Service(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _domain = configuration["Auth0:Domain"]!;
            _clientId = configuration["Auth0:ClientId"]!;
            _clientSecret = configuration["Auth0:ClientSecret"]!;
            _audience = configuration["Auth0:Audience"]!;
        }

        public async Task<string?> AuthenticateAsync(string username, string password)
        {
            var request = new HttpRequestMessage(
                HttpMethod.Post,
                $"https://{_domain}/oauth/token"
            );

            var content = new FormUrlEncodedContent(new Dictionary<string, string>
                    {
                        { "grant_type", "password" },
                        { "username", username },
                        { "password", password },
                        { "client_id", _clientId },
                        { "client_secret", _clientSecret },
                        { "audience", _audience }
                    });

            request.Content = content;

            try
            {
                var response = await _httpClient.SendAsync(request);

                if (!response.IsSuccessStatusCode)
                {
                    var errorJson = await response.Content.ReadAsStringAsync();
                    var auth0Error = JsonSerializer.Deserialize<Auth0ErrorResponse>(errorJson);

                    throw new HttpRequestException(
                        $"Auth0 Error: {auth0Error?.Error} - {auth0Error?.ErrorDescription}"
                    );
                }

                var responseData = await response.Content.ReadAsStringAsync();
                var tokenResponse = JsonSerializer.Deserialize<Auth0TokenResponse>(
                    responseData,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                );

                return tokenResponse?.AccessToken;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Auth0 Service Error] {ex.Message}");
                throw new HttpRequestException("Error de autenticación. Intente nuevamente.", ex);
            }
        }
    }
}