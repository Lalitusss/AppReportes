﻿using Azure.Storage.Queues;
using Microsoft.Extensions.Azure;
using System.Text;
using System.Text.Json;
namespace ReporteriaWS.Services
{
    public class QueueService
    {
        private readonly QueueClient _queueClient;

        public QueueService(string connectionString, string queueName)
        {
            _queueClient = new QueueClient(connectionString, queueName);
            _queueClient.CreateIfNotExists();
        }

        public async Task<string> EnqueueMessageAsync(ReporteParam reporteParam)
        {
            string message = JsonSerializer.Serialize(reporteParam);
            string messageUpdate = message.Replace("\\u0027", "'");
            string messageUpdateToBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(messageUpdate));

            var response = await _queueClient.SendMessageAsync(messageUpdateToBase64);
            return response.GetRawResponse().ClientRequestId;
        }
    }
}
