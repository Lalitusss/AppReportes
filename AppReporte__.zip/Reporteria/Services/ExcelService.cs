﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using ReporteriaWS.Common;
using System.Globalization;
using static JsonCast;

namespace ReporteriaWS.Services
{
    public interface IExcelService
    {
        Task<IActionResult> SendExcelToABS(SqlDataReader reader, string reportName, string Empresa);

        Task<IActionResult> SendExcelToABS(JsonData jsonData, string reportName, string Empresa);
    }

    public class ExcelService : IExcelService
    {
        private readonly AzureBlobStorageService _azureBlobStorageService;

        public ExcelService(AzureBlobStorageService azureBlobStorageService)
        {
            _azureBlobStorageService = azureBlobStorageService;
        }

        public async Task<IActionResult> SendExcelToABS(SqlDataReader reader, string reportName, string empresa)
        {
            try
            {
                using var excelPackage = new ExcelPackage();
                var worksheet = excelPackage.Workbook.Worksheets.Add(reportName.Replace(" ", "").ToLower());

                // Agregar encabezados de columna
                AddColumnHeaders(worksheet, reader);

                // Controlar si hay registros y agregar filas de datos
                if (!reader.HasRows)
                {
                    return new JsonResult(new { mensaje = "No hay registros para exportar." });
                }

                AddDataRows(worksheet, reader);

                var url = await UploadFileToAzureBlobStorage(excelPackage, reportName, empresa);

                return new JsonResult(new { mensaje = Messages.OperacionExitosa, fileUrl = url });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { mensaje = ex.Message });
            }
        }

        public async Task<IActionResult> SendExcelToABS(JsonData jsonData, string reportName, string Empresa)
        {
            try
            {
                using var excelPackage = new ExcelPackage();
                var worksheet = excelPackage.Workbook.Worksheets.Add(reportName.Replace(" ", "").ToLower());

                var columnNames = jsonData.columnHeaders?.Select(ch => ch.columnName).ToList();

                AddColumnHeaders(worksheet, columnNames!);

                //Aca controlar si hay registros mando mail sino aviso que no tiene.
                var dataRows = jsonData.data?.Select(x => x.row?.ToList()).ToArray();
                AddDataRows(worksheet, dataRows!);

                var url = await UploadFileToAzureBlobStorage(excelPackage, reportName, Empresa);

                return new JsonResult(new { mensaje = Messages.OperacionExitosa, fileUrl = url });
            }
            catch (Exception ex)
            {
                return new JsonResult(new { mensaje = ex.Message });
            }
        }

        private void AddColumnHeaders(ExcelWorksheet worksheet, SqlDataReader reader)
        {
            int columnCount = reader.FieldCount;
            ExcelRange headerRow = worksheet.Cells[1, 1, 1, columnCount];

            headerRow.Style.Fill.PatternType = ExcelFillStyle.Solid;
            headerRow.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            headerRow.Style.Font.Color.SetColor(System.Drawing.Color.Black);
            headerRow.Style.Font.Size = 12;
            headerRow.Style.Font.Bold = true;

            for (int i = 0; i < columnCount; i++)
            {
                worksheet.Cells[1, i + 1].Value = reader.GetName(i);
            }

            worksheet.Cells.AutoFitColumns();
        }

        private void AddColumnHeaders(ExcelWorksheet worksheet, List<string> columnNames)
        {
            ExcelRange headerRow = worksheet.Cells[1, 1, 1, columnNames.Count];

            headerRow.Style.Fill.PatternType = ExcelFillStyle.Solid;
            headerRow.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            headerRow.Style.Font.Color.SetColor(System.Drawing.Color.Black);
            headerRow.Style.Font.Size = 12;
            headerRow.Style.Font.Bold = true;

            for (int i = 0; i < columnNames.Count; i++)
            {
                worksheet.Cells[1, i + 1].Value = columnNames[i];
            }

            worksheet.Cells.AutoFitColumns();
        }

        private void AddDataRows(ExcelWorksheet worksheet, SqlDataReader reader)
        {
            int rowIndex = 2; // Comenzar en la fila 2 porque la fila 1 son los encabezados
            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if (reader[i] != DBNull.Value) // Verificar si el valor no es nulo
                    {
                        string cellValue = reader[i].ToString(); // Convertir el valor a string

                        if (reader[i] is DateTime dateValue)
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = dateValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "dd/MM/yyyy";
                        }
                        else if (!string.IsNullOrEmpty(cellValue) &&
                                 (cellValue.Length > 4 && cellValue.All(char.IsDigit) ||
                                  (cellValue.Length == 22 && cellValue.IndexOf('.') == -1 && cellValue.IndexOf(',') == -1)))
                        {
                            // Si cumple con las condiciones de longitud y no tiene puntos ni comas
                            worksheet.Cells[rowIndex, i + 1].Value = cellValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "@"; // Formato texto
                        }
                        else if (long.TryParse(cellValue, out long intValue))
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = intValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "0";
                        }
                        else if (double.TryParse(cellValue, NumberStyles.Any, CultureInfo.InvariantCulture, out double numberValue))
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = numberValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "#,##0.00";
                        }
                        else
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = cellValue; // Usar cellValue directamente
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "@"; // Formato texto
                        }
                    }
                }
                rowIndex++;
            }

            worksheet.Cells.AutoFitColumns(); // Ajustar automáticamente las columnas
            int maxColumnWidth = 50;
            for (int i = 1; i <= worksheet.Dimension.Columns; i++)
            {
                if (worksheet.Column(i).Width > maxColumnWidth)
                {
                    worksheet.Column(i).Width = maxColumnWidth;
                }
            }
        }

        private void AddDataRows(ExcelWorksheet worksheet, List<string>[] dataRows)
        {
            int rowIndex = 2;
            foreach (var row in dataRows)
            {
                for (int i = 0; i < row.Count; i++)
                {
                    if (row[i] != null)
                    {
                        if (DateTime.TryParse(row[i], out DateTime dateValue))
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = dateValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "dd/MM/yyyy";
                        }
                        else if (row[i].Length > 4 && row[i].All(char.IsDigit) || row[i].Length == 22 && row[i].IndexOf('.') == -1 && row[i].IndexOf(',') == -1)
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = row[i];
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "@";
                        }
                        else if (long.TryParse(row[i], out long intValue))
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = intValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "0";
                        }
                        else if (double.TryParse(row[i], NumberStyles.Any, CultureInfo.InvariantCulture, out double numberValue))
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = numberValue;
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "#,##0.00";
                        }
                        else
                        {
                            worksheet.Cells[rowIndex, i + 1].Value = row[i];
                            worksheet.Cells[rowIndex, i + 1].Style.Numberformat.Format = "@";
                        }
                    }
                }
                rowIndex++;
            }
            worksheet.Cells.AutoFitColumns();
            int maxColumnWidth = 50;
            for (int i = 1; i <= worksheet.Dimension.Columns; i++)
            {
                if (worksheet.Column(i).Width > maxColumnWidth)
                {
                    worksheet.Column(i).Width = maxColumnWidth;
                }
            }
        }

        private async Task<string> UploadFileToAzureBlobStorage(ExcelPackage excelPackage, string reportName, string Empresa)
        {
            try
            {
                using var memoryStream = new MemoryStream();
                excelPackage.SaveAs(memoryStream);
                memoryStream.Position = 0;
                var urlFile = (Empresa + @"\" + reportName + "_" + DateTime.Now.ToString("yyyy-MM-dd") + ".xlsx");
                var respuesta = await _azureBlobStorageService.SubirArchivo(memoryStream, urlFile);
                return respuesta;
            }
            catch (Exception ex)
            {
                return Messages.ErrorSubirArchivo + " _ " + ex.Message;
            }
        }
    }
}