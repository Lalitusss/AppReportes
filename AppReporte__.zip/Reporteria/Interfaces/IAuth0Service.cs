﻿public interface IAuth0Service
{
    Task<string?> AuthenticateAsync(string username, string password);
}