﻿using Microsoft.WindowsAzure.Storage.Table;

public class ReporteStatusEntity : TableEntity
{
    public string ReportName { get; set; }
    public string JsonToSend { get; set; }
    public string User { get; set; }
    public string StartDate { get; set; }
    public string EndDate { get; set; }
    public string Url { get; set; }
    public string EstadoEnvio { get; set; }

    public ReporteStatusEntity(string partitionKey, string rowKey)
    {
        PartitionKey = partitionKey;
        RowKey = rowKey;
    }

    public ReporteStatusEntity() { } // Constructor sin parámetros requerido
}
