﻿namespace ReporteriaWS.Common
{
    public static class Messages
    {
        public static readonly string OperacionExitosa = "Operación exitosa";
        public static readonly string ErrorAlGenerarReporte = "Error al generar el reporte: {0}";
        public static readonly string ReporteGeneradoCorrectamente = "Reporte generado correctamente";
        public static readonly string ErrorDeConexion = "Error de conexión con la base de datos";
        public static readonly string DatosNoEncontrados = "Datos no encontrados";
        public static readonly string ErrorSubirArchivo = "Error al subir el archivo: ";

        public static readonly string SelectAllFromDBO = "SELECT * FROM DBO.{0}";

        public static readonly string SelectAllExcludeFields = @"DECLARE @COLUMNAS VARCHAR(MAX);
                                                                DECLARE @CONSULTA VARCHAR(MAX);

                                                                SELECT @COLUMNAS = STRING_AGG(COLUMN_NAME, ',')
                                                                FROM INFORMATION_SCHEMA.COLUMNS
                                                                WHERE TABLE_NAME = '{0}'
                                                                AND TABLE_SCHEMA = '{1}'
                                                                AND COLUMN_NAME NOT IN ('{2}');

                                                                SET @CONSULTA = 'SELECT ' + @COLUMNAS + ' FROM {1}.{0} {3}';

                                                                EXEC(@CONSULTA)";

        public static readonly string SelectAllExcludeTypeFields = @"DECLARE @COLUMNAS VARCHAR(MAX);
                                                                DECLARE @CONSULTA VARCHAR(MAX);

                                                                SELECT @COLUMNAS = STRING_AGG(COLUMN_NAME, ',')
                                                                FROM INFORMATION_SCHEMA.COLUMNS
                                                                WHERE TABLE_NAME = '{0}'
                                                                AND TABLE_SCHEMA = '{1}'
                                                                AND DATA_TYPE NOT IN ('text','image')
                                                                AND COLUMN_NAME <> '{3}';

                                                                SET @CONSULTA = 'SELECT ' + @COLUMNAS + ' FROM {1}.{0} {2}';

                                                                EXEC(@CONSULTA)";

        public static readonly string WhereEstatico = " WHERE 1=1";
        public static readonly string Esquema = "DBO";
        public static readonly string TipoExcel = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }
}