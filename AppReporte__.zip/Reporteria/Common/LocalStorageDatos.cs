﻿public class LocalStorage
{
    public class Datos
    {
        public string guidFromFE { get; set; }
        public string reporte { get; set; }
        public string respuesta { get; set; }
        public string archivoTexto { get; set; }
        public string horaFin { get; set; }
        public string cliente { get; set; }
    }
    public class DatosRequest
    {
        public List<Datos> datos { get; set; }
    }
}