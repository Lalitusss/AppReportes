﻿using System.Data;

public class JsonCast
{
    public class JsonData
    {
        public List<ColumnHeader>? columnHeaders { get; set; }
        public List<Data>? data { get; set; }
    }

    public class ColumnHeader
    {
        public string? columnName { get; set; }
        //      public string? columnType { get; set; }
    }

    public class Data
    {
        public List<string>? row { get; set; }
    }

    public static JsonData ConvertDataReaderToJson(IDataReader dataReader)
    {
        var jsonData = new JsonData
        {
            columnHeaders = new List<ColumnHeader>(),
            data = new List<Data>()
        };

        for (var i = 0; i < dataReader.FieldCount; i++)
        {
            var columnHeader = new ColumnHeader
            {
                columnName = dataReader.GetName(i)
            };

            jsonData.columnHeaders.Add(columnHeader);
        }

        while (dataReader.Read())
        {
            var data = new Data
            {
                row = new List<string>()
            };

            for (var i = 0; i < dataReader.FieldCount; i++)
            {
                data.row.Add(dataReader[i].ToString()!);
            }

            jsonData.data.Add(data);
        }

        return jsonData;
    }
}