﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

public class Reporte
{
    [JsonPropertyName("Id")]
    public int Id { get; set; }

    [JsonPropertyName("Texto")]
    public string? Texto { get; set; }

    [JsonPropertyName("Vista")]
    public string? Vista { get; set; }

    [JsonPropertyName("Base")]
    public int Base { get; set; }

    [JsonPropertyName("CantParam")]
    public List<string>? CantParam { get; set; }
}

public class ReporteParam
{
    [JsonPropertyName("Report")]
    public string? Report { get; set; }
    [JsonPropertyName("UserName")]
    public string? UserName { get; set; }
    [JsonPropertyName("GuidFromFE")]
    public string? GuidFromFE { get; set; }
    [JsonPropertyName("QueryParams")]
    public string? QueryParams { get; set; }
    [JsonPropertyName("EsHistorico")]
    public bool EsHistorico { get; set; }
    [JsonPropertyName("ReporteJson")]
    public Reporte? ReporteJson { get; set; }
}
