using Microsoft.Extensions.Hosting;
using OfficeOpenXml;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .Build();
ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

host.Run();
