﻿using Azure.Core;
using Azure.Storage.Blobs;
using Azure.Storage.Queues.Models;
using Microsoft.AspNet.SignalR.Messaging;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using static Enums;

namespace RunSqlToExcel.Common
{
    public class StorageMovements
    {
        public StorageMovements() { }

        public static async Task InsertReportDataAsync(QueueMessage message, ReporteParam reporteParam)
        {
            var storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("ABSConnection"));
            var tableClient = storageAccount.CreateCloudTableClient();
            var tabla = tableClient.GetTableReference("ReporteStatus");
            DateTime utcNow = DateTime.UtcNow;

            var entidad = new ReporteStatusEntity(message.MessageId, reporteParam.GuidFromFE!)
            {
                ReportName = reporteParam.Report!,
                JsonToSend = message.Body.ToString(),
                User = reporteParam.UserName!,
                StartDate = utcNow.ToString("HH:mm:ss"),
                EndDate = string.Empty,
                Url = string.Empty,
                EstadoEnvio = EstadosDeEnvio.Solicitando.ToString()
            };

            await tabla.ExecuteAsync(TableOperation.Insert(entidad));
        }

        public static async Task UpdateReportDataErrorAsync(string partitionKey, string rowKey, string error)
        {
            var storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("ABSConnection"));
            var tableClient = storageAccount.CreateCloudTableClient();
            var tabla = tableClient.GetTableReference("ReporteStatus");

            TableOperation retrieveOperation = TableOperation.Retrieve<ReporteStatusEntity>(partitionKey, rowKey);
            TableResult retrievedResult = await tabla.ExecuteAsync(retrieveOperation);

            if (retrievedResult.Result != null)
            {
                ReporteStatusEntity updateEntity = (ReporteStatusEntity)retrievedResult.Result;

                DateTime utcNow = DateTime.UtcNow;

                updateEntity.EndDate = utcNow.ToString("HH:mm:ss");
                updateEntity.Url = error;
                updateEntity.EstadoEnvio = EstadosDeEnvio.Error.ToString();

                TableOperation updateOperation = TableOperation.Replace(updateEntity);
                await tabla.ExecuteAsync(updateOperation);
            }
        }
        public static async Task UpdateReportDataAsync(string partitionKey, string rowKey, string url)
        {
            var storageAccount = CloudStorageAccount.Parse(Environment.GetEnvironmentVariable("ABSConnection"));
            var tableClient = storageAccount.CreateCloudTableClient();
            var tabla = tableClient.GetTableReference("ReporteStatus");

            TableOperation retrieveOperation = TableOperation.Retrieve<ReporteStatusEntity>(partitionKey, rowKey);
            TableResult retrievedResult = await tabla.ExecuteAsync(retrieveOperation);

            if (retrievedResult.Result != null)
            {
                ReporteStatusEntity updateEntity = (ReporteStatusEntity)retrievedResult.Result;

                DateTime utcNow = DateTime.UtcNow;

                updateEntity.EndDate = utcNow.ToString("HH:mm:ss");
                updateEntity.Url = url;
                updateEntity.EstadoEnvio = EstadosDeEnvio.Finalizado.ToString();

                TableOperation updateOperation = TableOperation.Replace(updateEntity);
                await tabla.ExecuteAsync(updateOperation);
            }
        }
        public static async Task UploadExcelToBlobStorage(Stream excelStream, string _blobName, FunctionContext context, string partitionKey, string rowKey)
        {
            var logger = context.GetLogger("ExcelExport");

            try
            {
                string _conexionString = Environment.GetEnvironmentVariable("ABSConnection")!;
                string _containerName = Environment.GetEnvironmentVariable("ABSContainerName")!;

                // Configurar opciones del cliente (timeout y reintentos)
                var blobClientOptions = new BlobClientOptions
                {
                    Retry = {
                    MaxRetries = 5, // Número máximo de reintentos
                    Mode = RetryMode.Exponential, // Reintentos exponenciales
                    Delay = TimeSpan.FromSeconds(1), // Tiempo inicial entre reintentos
                    MaxDelay = TimeSpan.FromSeconds(10), // Tiempo máximo entre reintentos
                    NetworkTimeout = TimeSpan.FromMinutes(5) // Tiempo de espera de red
                }
                };

                BlobServiceClient blobServiceClient = new BlobServiceClient(_conexionString, blobClientOptions);
                BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                await containerClient.CreateIfNotExistsAsync();

                BlobClient blobClient = containerClient.GetBlobClient(_blobName);
                excelStream.Position = 0;
                logger.LogInformation("Sube Excel?");

                await blobClient.UploadAsync(excelStream, overwrite: true);
                await UpdateReportDataAsync(partitionKey, rowKey, blobClient.Uri.ToString());
                logger.LogInformation($"Archivo subido exitosamente a Blob Storage: {blobClient.Uri}");
            }
            catch (Exception ex)
            {
                _ = StorageMovements.UpdateReportDataErrorAsync(partitionKey, rowKey,"Error al crear Excel - " + ex.Message);
                logger.LogError($"Error subiendo a Blob Storage: {ex.Message}");
            }
        }

    }
}
