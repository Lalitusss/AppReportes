﻿public static class Enums
{
    public enum Empresa
    {
        Ninguna = 0,
        Action = 1,
        Mifos = 2
    }

    public enum DBAction
    {
        Cobranzas = 1,
        DatosPersonales = 2
    }

    public enum EstadosDeEnvio
    {
        Solicitando = 1,
        Finalizado = 2,
        Error = 3
    }

}