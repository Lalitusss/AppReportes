using Azure.Storage.Queues.Models;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using RunSqlToExcel.Common;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using static Enums;
using static JsonCast;

namespace RunSqlToExcel
{
    public static class Configuracion
    {
        public static string MifosUser { get; private set; } = Environment.GetEnvironmentVariable("MifosUser")!;
        public static string MifosPass { get; private set; } = Environment.GetEnvironmentVariable("MifosPass")!;
        public static string MifosUrl { get; private set; } = Environment.GetEnvironmentVariable("MifosUrl")!;
        public static string MifosUrlParams { get; private set; } = Environment.GetEnvironmentVariable("MifosUrlParams")!;
    }
    public static class CrearReporteMifos
    {
        [Function("CrearReporteMifos")]
        public static async Task Run(
            [QueueTrigger("queue-mifos", Connection = "ABSConnection")] QueueMessage message,
            FunctionContext context)
        {
            var logger = context.GetLogger("ExcelExport");
            ReporteParam? reporteParam = null;
            var queueItem = message.Body.ToString();

            try
            {
                if (string.IsNullOrEmpty(queueItem))
                {
                    logger.LogError("El mensaje de la cola est� vac�o o es nulo.");
                    return;
                }

                reporteParam = JsonSerializer.Deserialize<ReporteParam>(queueItem)!;

                if (reporteParam == null)
                {
                    throw new Exception("El objeto ReporteParam deserializado es nulo.");
                }
            }
            catch (JsonException ex)
            {
                logger.LogError($"Error al deserializar el cuerpo de la cola: {ex.Message}, Contenido del mensaje: {queueItem}");
                return;
            }
            catch (Exception ex)
            {
                logger.LogError($"Error procesando el mensaje: {ex.Message}");
                return;
            }
            await StorageMovements.InsertReportDataAsync(message, reporteParam);

            try
            {
                var client = ConfigureClient();
                logger.LogInformation("Empieza la conexion API");

                var jsonData = await GetDataInPartsAsync(client, reporteParam);
                logger.LogInformation("Paso la API");


                using (var package = new ExcelPackage())
                {
                    var EsHistorico = reporteParam.EsHistorico;

                    var reporteName = reporteParam.Report!.ToUpper();
                    var worksheet = package.Workbook.Worksheets.Add(reporteName);
                    worksheet.Cells.Style.Font.Name = "Calibri";
                    worksheet.Cells.Style.Font.Size = 10;

                    var datos = jsonData;

                    var headers = datos.columnHeaders.Select(h => h.columnName).ToList();
                    for (int col = 0; col < headers.Count; col++)
                    {
                        worksheet.Cells[1, col + 1].Value = headers[col];
                        worksheet.Cells[1, col + 1].Style.Font.Bold = true;
                        worksheet.Cells[1, col + 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                        worksheet.Cells[1, col + 1].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                    }

                    var dataRows = jsonData.data?.Select(x => x.row?.ToList()).ToArray();
                    logger.LogInformation("Empieza a crear el Excel");

                    AddDataRows(worksheet, dataRows!);
                    logger.LogInformation("Fin Excel");

                    //worksheet.Cells.AutoFitColumns();

                    if (EsHistorico)
                        reporteName = "HISTORICO_" + reporteName;
                    string blobName = (Empresa.Mifos.ToString() + @"/" + reporteName + "_" + DateTime.Now.ToString("yyyy_MM_dd") + ".xlsx");

                    using (var stream = new MemoryStream())
                    {
                        package.SaveAs(stream);
                        stream.Position = 0;

                        await StorageMovements.UploadExcelToBlobStorage(stream, blobName, context, message.MessageId, reporteParam.GuidFromFE!);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                _ = StorageMovements.UpdateReportDataErrorAsync(message.MessageId, reporteParam.GuidFromFE!, "Not found - " + ex.Message);
                logger.LogError($"Error: {ex.Message}");
                return;
            }
        }
        public static void AddDataRows(ExcelWorksheet worksheet, List<string>[] dataRows)
        {
            var cellBuffer = new object[dataRows[0].Count];
            int rowIndex = 2;

            foreach (var row in dataRows)
            {
                for (int i = 0; i < row.Count; i++)
                {
                    if (row[i] != null)
                    {
                        if (DateTime.TryParse(row[i], out DateTime dateValue))
                        {
                            cellBuffer[i] = dateValue;
                        }
                        else if (row[i].Length > 4 && row[i].All(char.IsDigit) || row[i].Length == 22 && row[i].IndexOf('.') == -1 && row[i].IndexOf(',') == -1)
                        {
                            cellBuffer[i] = row[i];
                        }
                        else if (long.TryParse(row[i], out long intValue))
                        {
                            cellBuffer[i] = intValue;
                        }
                        else if (double.TryParse(row[i], NumberStyles.Any, CultureInfo.InvariantCulture, out double numberValue))
                        {
                            cellBuffer[i] = numberValue;
                        }
                        else
                        {
                            cellBuffer[i] = row[i];
                        }
                    }
                    else
                    {
                        cellBuffer[i] = null;
                    }
                }

                worksheet.Cells[rowIndex, 1].LoadFromArrays(new object[][] { cellBuffer });

                rowIndex++;
            }

            // Aplicar formatos por columna
            for (int col = 0; col < dataRows[0].Count; col++)
            {
                var sampleValues = dataRows.Select(r => r[col]);

                if (sampleValues.All(v => v != null && DateTime.TryParse(v, out _)))
                {
                    worksheet.Column(col + 1).Style.Numberformat.Format = "dd/MM/yyyy";
                }
                else if (sampleValues.All(v => v != null && (long.TryParse(v, out _) || double.TryParse(v, NumberStyles.Any, CultureInfo.InvariantCulture, out _))))
                {
                    if (sampleValues.Any(v => double.TryParse(v, NumberStyles.Any, CultureInfo.InvariantCulture, out _)))
                    {
                        worksheet.Column(col + 1).Style.Numberformat.Format = "#,##0.00";
                    }
                    else
                    {
                        worksheet.Column(col + 1).Style.Numberformat.Format = "0";
                    }
                }
                else
                {
                    worksheet.Column(col + 1).Style.Numberformat.Format = "@";
                }
            }

            worksheet.View.ShowGridLines = false;
            worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns(12, 50);
        }


        public static HttpClient ConfigureClient()
        {
            var handler = new HttpClientHandler
            {
                ClientCertificateOptions = ClientCertificateOption.Manual,
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true,
                Credentials = new NetworkCredential(Configuracion.MifosUser, Configuracion.MifosPass)
            };

            var client = new HttpClient(handler)
            {
                BaseAddress = Configuracion.MifosUrl != null ? new Uri(Configuracion.MifosUrl) : null,
                Timeout = TimeSpan.FromMinutes(60)
            };

            return client;
        }
        public static async Task<JsonData> BuildRequestAsync(HttpClient client, string reportName, string queryParams)
        {
            var uriBuilder = new UriBuilder(client.BaseAddress + "runreports/" + reportName);
            uriBuilder.Query = Configuracion.MifosUrlParams + "&" + queryParams;

            var request = new HttpRequestMessage(HttpMethod.Get, uriBuilder.Uri);
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.ASCII.GetBytes(Configuracion.MifosUser + ":" + Configuracion.MifosPass)));



            var response = await client.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();
            return System.Text.Json.JsonSerializer.Deserialize<JsonData>(responseBody);
        }

        static DateTime GetDateFromQueryString(string queryString, string parameterName, DateTime defaultValue)
        {
            string[] parameters = queryString.Split('&');
            foreach (string param in parameters)
            {
                if (param.StartsWith(parameterName + "="))
                {
                    string dateValue = param.Split('=')[1];
                    if (DateTime.TryParseExact(dateValue, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
                    {
                        return parsedDate;
                    }
                }
            }
            return defaultValue;
        }
        public static async Task<JsonData> GetDataInPartsAsync(HttpClient client, ReporteParam reportParam)
        {
            var timeout = TimeSpan.FromSeconds(3000);

            client.Timeout = timeout;
            var jsonData = new JsonData();

            var queryString = reportParam.QueryParams!;

            var startDate = GetDateFromQueryString(queryString, "R_startDate", new DateTime(2020, 1, 1));
            var endDate = GetDateFromQueryString(queryString, "R_endDate", DateTime.Now);
            if (endDate > DateTime.Now)
                endDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);


            var interval = reportParam.EsHistorico ? TimeSpan.FromDays(183) : TimeSpan.FromDays(0);

            var currentDate = startDate;
            var cant = 0;
            while (currentDate <= endDate)
            {
                cant++;
                var queryParams = $"R_startDate={currentDate.ToString("yyyy-MM-dd")}&R_endDate={currentDate.AddMonths(6).ToString("yyyy-MM-dd")}";

                var partialData = await BuildRequestAsync(client, reportParam.Report!, queryParams);


                if (jsonData.columnHeaders == null)
                {
                    jsonData.columnHeaders = partialData.columnHeaders;
                }

                if (jsonData.data == null)
                {
                    jsonData.data = partialData.data;
                }
                else
                {
                    if (partialData.data != null)
                    {
                        jsonData.data.AddRange(partialData.data);
                    }
                }

                currentDate = currentDate.AddMonths(6);
            }

            return jsonData;
        }
    }
}
