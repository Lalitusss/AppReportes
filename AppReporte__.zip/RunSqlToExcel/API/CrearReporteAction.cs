using Azure.Storage.Blobs;
using Azure.Storage.Queues.Models;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using RunSqlToExcel.Common;
using System.Data;
using System.Drawing;
using System.Text.Json;
using static Enums;

namespace RunSqlToExcel
{
    public static class CrearReporteAction
    {
        [Function("CrearReporteAction")]
        public static async Task Run(
            [QueueTrigger("queue-action", Connection = "ABSConnection")] QueueMessage message,
            FunctionContext context)
        {
            var logger = context.GetLogger("ExcelExport");
            ReporteParam? reporteParam = null;
            var queueItem = message.Body.ToString();

            try
            {
                if (string.IsNullOrEmpty(queueItem))
                {
                    logger.LogError("El mensaje de la cola est� vac�o o es nulo.");
                    return;
                }

                reporteParam = JsonSerializer.Deserialize<ReporteParam>(queueItem)!;

                if (reporteParam == null)
                {
                    throw new Exception("El objeto ReporteParam deserializado es nulo.");
                }
            }
            catch (JsonException ex)
            {
                logger.LogError($"Error al deserializar el cuerpo de la cola: {ex.Message}, Contenido del mensaje: {queueItem}");
                return;
            }
            catch (Exception ex)
            {
                logger.LogError($"Error procesando el mensaje: {ex.Message}");
                return;
            }

            await StorageMovements.InsertReportDataAsync(message, reporteParam);
            var sqlQuery = string.Format("SELECT * FROM dbo.{0} {1}",
                                    reporteParam.ReporteJson!.Vista,
                                    reporteParam.QueryParams);

            try
            {
                var _conn = reporteParam.ReporteJson.Base == (int)Enums.DBAction.Cobranzas
                    ? Environment.GetEnvironmentVariable("ActionCobranzas")
                    : Environment.GetEnvironmentVariable("ActionDatosPersonales");

                logger.LogInformation("Conecto");
                DataTable dataTable = new DataTable();
                using (SqlConnection connection = new SqlConnection(_conn))
                {
                    await connection.OpenAsync();
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        command.CommandTimeout = 3600;
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            dataTable.Load(reader); // Carga as�ncrona
                        }
                    }
                }
                logger.LogInformation("Creo el DataTable");
                using (var package = new ExcelPackage())
                {
                    var EsHistorico = reporteParam.EsHistorico;
                    var reporteName = reporteParam.ReporteJson.Texto!.ToUpper();
                    var worksheet = package.Workbook.Worksheets.Add(reporteName);

                    // 1. Cargar SOLO cabeceras
                    if (dataTable.Columns.Count > 0)
                    {
                        var headerData = dataTable.Clone();
                        headerData.Clear();
                        worksheet.Cells["A1"].LoadFromDataTable(headerData, true); // Solo headers
                    }

                    // 2. Escribir datos directamente sin clonar DataTables
                    int batchSize = 5000;
                    int currentRow = 2; // Fila inicial despu�s de las cabeceras

                    for (int i = 0; i < dataTable.Rows.Count; i += batchSize)
                    {
                        var batch = dataTable.AsEnumerable().Skip(i).Take(batchSize);

                        foreach (DataRow row in batch)
                        {
                            for (int col = 0; col < dataTable.Columns.Count; col++)
                            {
                                worksheet.Cells[currentRow, col + 1].Value = row[col];
                            }
                            currentRow++;
                        }

                        // Liberar recursos del batch
                        GC.Collect();
                    }

                    // 3. Formateo optimizado
                    using (var headerRange = worksheet.Cells[1, 1, 1, dataTable.Columns.Count])
                    {
                        headerRange.Style.Font.Bold = true;
                        headerRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        headerRange.Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                    }

                    // 4. Evitar AutoFitColumns
                    worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns(); // Solo si es indispensable

                    // 5. Guardar directamente en Blob Storage sin MemoryStream
                    if (EsHistorico)
                        reporteName = "HISTORICO_" + reporteName;
                    string blobName = $"{Empresa.Action}/{reporteName}_{DateTime.Now:yyyy_MM_dd}.xlsx";
                    using (var stream = new MemoryStream())
                    {
                        package.SaveAs(stream);
                        stream.Position = 0;
                        await StorageMovements.UploadExcelToBlobStorage(stream, blobName, context, message.MessageId, reporteParam.GuidFromFE!);
                    }
                }

                //using (var package = new ExcelPackage())
                //{
                //    var EsHistorico = reporteParam.EsHistorico;

                //    var reporteName = reporteParam.ReporteJson.Texto!.ToUpper();
                //    var worksheet = package.Workbook.Worksheets.Add(reporteName);
                //    logger.LogInformation("Intenta pasar a Excel " + reporteName);
                //    logger.LogInformation("Cantidad de Registros:" + dataTable.Rows.Count);

                //    int registrosPorCarga = 5000;
                //    int filasTotales = dataTable.Rows.Count;
                //    int cargasNecesarias = (int)Math.Ceiling((double)filasTotales / registrosPorCarga);

                //    int filaActual = 1; // Posici�n inicial para la carga

                //    // Cargar cabeceras solo una vez
                //    if (dataTable.Rows.Count > 0)
                //    {
                //        worksheet.Cells[$"A{filaActual}"].LoadFromDataTable(dataTable, true);
                //        filaActual += 1; // Ajustar la posici�n para el primer conjunto de datos
                //    }

                //    for (int i = 0; i < cargasNecesarias; i++)
                //    {
                //        int inicio = i * registrosPorCarga;
                //        int fin = Math.Min((i + 1) * registrosPorCarga, filasTotales);

                //        // Crear un DataTable temporal para la parte actual
                //        var dataTablePart = dataTable.Clone();
                //        for (int j = inicio; j < fin; j++)
                //        {
                //            dataTablePart.ImportRow(dataTable.Rows[j]);
                //        }

                //        // Ajustar la posici�n de carga seg�n la fila actual
                //        // Cargar datos sin cabeceras
                //        worksheet.Cells[$"A{filaActual}"].LoadFromDataTable(dataTablePart, false);

                //        // Actualizar la posici�n de inicio para la pr�xima carga
                //        filaActual += dataTablePart.Rows.Count;
                //    }

                //    // Formatear cabeceras
                //    for (int col = 1; col <= dataTable.Columns.Count; col++)
                //    {
                //        worksheet.Cells[1, col].Style.Font.Bold = true;
                //        worksheet.Cells[1, col].Style.Fill.PatternType = ExcelFillStyle.Solid;
                //        worksheet.Cells[1, col].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
                //    }

                //    worksheet.Cells.Style.Font.Name = "Calibri";
                //    worksheet.Cells.Style.Font.Size = 10;

                //    int createdOnColumnIndex = dataTable.Columns.Contains("CreatedOnDataBase") ? dataTable.Columns["CreatedOnDataBase"].Ordinal + 1 : -1;

                //    if (createdOnColumnIndex != -1)
                //        worksheet.Cells[2, createdOnColumnIndex, worksheet.Dimension.End.Row, createdOnColumnIndex].Style.Numberformat.Format = "dd-MM-yyyy HH:mm";

                //    //worksheet.Cells.AutoFitColumns();

                //    if (EsHistorico)
                //        reporteName = "HISTORICO_" + reporteName;
                //    string blobName = (Empresa.Action.ToString() + @"/" + reporteName + "_" + DateTime.Now.ToString("yyyy_MM_dd") + ".xlsx");

                //    using (var stream = new MemoryStream())
                //    {
                //        package.SaveAs(stream);
                //        stream.Position = 0;
                //        await StorageMovements.UploadExcelToBlobStorage(stream, blobName, context, message.MessageId, reporteParam.GuidFromFE!);
                //        return;
                //    }
                //}
            }
            catch (Exception ex)
            {
                _ = StorageMovements.UpdateReportDataErrorAsync(message.MessageId, reporteParam.GuidFromFE!, "Not found - " + ex.Message);
                logger.LogError($"Error: {ex.Message}");
                return;
            }
        }
    }
}
