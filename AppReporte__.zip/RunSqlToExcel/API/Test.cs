﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage;
using Newtonsoft.Json;
using static Enums;
using System;

namespace RunSqlToExcel
{
    public static class ProcesaJson
    {
        [Function("ProcesaJson")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "ProcesaJson")] HttpRequest req,
            ILogger log)
        {

 
            string mensaje = $"Hola";

            return new OkObjectResult(mensaje);
        }
    }
}