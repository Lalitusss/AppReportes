﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace RunSqlToExcel
{
    public static class ReportesHistoricos
    {
        //Hora UTC
        [Function("ReportesHistoricos")]
        public static async Task Run([TimerTrigger("0 0 2-8 * * *", RunOnStartup = false)]
                 FunctionContext context)
        //public static async Task Run([TimerTrigger("0 * * * * *", RunOnStartup = false)]
        //         FunctionContext context)
        {
            // Logger para registrar información en la ejecución
            var logger = context.GetLogger("ReportesHistoricos");
            logger.LogInformation("Arranca los historicos...");

            try
            {
                TimeZoneInfo zonaHoraria = TimeZoneInfo.FindSystemTimeZoneById("America/Buenos_Aires");
                DateTimeOffset horaActual = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, zonaHoraria);
                int hora = horaActual.Hour;
                //int hora = 16;

                logger.LogInformation($"Función ejecutada a las {horaActual}.");

                //En el TimeTrigger usa UTC +3 de nueva zona horaria.
                switch (hora)
                {
                    case 23:
                        await EjecutarReporteActionAsync(9); //Otorgados y Cerrados
                        await EjecutarReporteMifosAsync(278); //Todas las cuotas pagas reporte
                        break;
                    case 0:
                        await EjecutarReporteActionAsync(7); //En foco
                        await EjecutarReporteMifosAsync(279); //Todas las transacciones pagas reporte
                        break;
                    case 1:
                        await EjecutarReporteMifosAsync(266); //Todas las cuotas
                        break;
                    case 2:
                        await EjecutarReporteMifosAsync(221); //PlanillaMorosos
                        break;                     
                    case 3:
                        await EjecutarReporteMifosAsync(321); //Cobrado En Fecha
                        break;                     
                    case 4:
                        await EjecutarReporteMifosAsync(277); //Todas las cuotas reporte
                        break;                   
                    case 5:
                        await EjecutarReporteActionAsync(6); //Ultimos Logins
                        break;
                    default:
                        logger.LogWarning($"No hay tareas programadas para la hora actual: {hora} UTC.");
                        break;
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                logger.LogError($"Ocurrió un error en la función: {ex.Message}");
            }
        }
        private static async Task EjecutarReporteActionAsync(int idReporte)
        {
            QueueClient _queueClient = new QueueClient(Environment.GetEnvironmentVariable("ABSConnection"), "queue-action");
            _queueClient.CreateIfNotExists();
            ReporteParam reporteParam = new ReporteParam();

            var rutaArchivo = Path.Combine(Environment.GetEnvironmentVariable("HOME")!, "site", "wwwroot", "Reportes", "Action.json");
            var json = System.IO.File.ReadAllText(rutaArchivo);
            var rep = JsonSerializer.Deserialize<List<Reporte>>(json);
            var reportesFiltrados = rep?.Where(r => r.Id == idReporte).ToList();

            Guid guid = Guid.NewGuid();

            string qry = " WHERE CONVERT(DATE, CreatedOnDataBase, 103) BETWEEN '20200101' AND '{0}' ORDER BY CreatedOnDataBase ";
            string shortGuid = guid.ToString().Replace("-", "").Substring(0, 12);

            DateTime fechaActual = DateTime.Now;
            string fechaFormateada = fechaActual.ToString("yyyyMMdd");

            reporteParam.Report = reportesFiltrados![0].Texto;
            reporteParam.UserName = "UserAction";
            reporteParam.GuidFromFE = shortGuid;
            reporteParam.QueryParams = string.Format(qry, fechaFormateada);
            reporteParam.ReporteJson = reportesFiltrados?.FirstOrDefault(r => r.Texto == reporteParam.Report);
            reporteParam.EsHistorico = true;

            string message = JsonSerializer.Serialize(reporteParam);
            string messageUpdate = message.Replace("\\u0027", "'");
            string messageUpdateToBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(messageUpdate));

            await _queueClient.SendMessageAsync(messageUpdateToBase64);
        }

        private static async Task EjecutarReporteMifosAsync(int idReporte)
        {
            QueueClient _queueClient = new QueueClient(Environment.GetEnvironmentVariable("ABSConnection"), "queue-mifos");
            _queueClient.CreateIfNotExists();
            ReporteParam reporteParam = new ReporteParam();
            //Azure
            var rutaArchivo = Path.Combine(Environment.GetEnvironmentVariable("HOME")!, "site", "wwwroot", "Reportes", "Mifos.json");
            //Local
            //var rutaArchivo = Path.Combine(Directory.GetCurrentDirectory(), "Reportes", "Mifos.json");

            var json = System.IO.File.ReadAllText(rutaArchivo);
            var rep = JsonSerializer.Deserialize<List<Reporte>>(json);
            var reportesFiltrados = rep?.Where(r => r.Id == idReporte).ToList();

            Guid guid = Guid.NewGuid();

            string qry = "R_startDate=2020-01-01&R_endDate={0}";
            string shortGuid = guid.ToString().Replace("-", "").Substring(0, 12);

            DateTime fechaActual = DateTime.Now;
            string fechaFormateada = fechaActual.ToString("yyyy-MM-dd");

            reporteParam.Report = reportesFiltrados![0].Texto;
            reporteParam.UserName = "UserMifos";
            reporteParam.GuidFromFE = shortGuid;
            reporteParam.QueryParams = string.Format(qry, fechaFormateada);
            reporteParam.ReporteJson = null;
            reporteParam.EsHistorico = true;

            string message = JsonSerializer.Serialize(reporteParam);
            string messageUpdate = message.Replace("\\u0027", "'");
            string messageUpdateToBase64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(message));

            await _queueClient.SendMessageAsync(messageUpdateToBase64);
        }
    }
}
