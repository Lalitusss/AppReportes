Repositorio creado para la centralización de reportes.
